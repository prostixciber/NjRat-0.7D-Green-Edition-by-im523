# NjRat 0.7D Green Edition by im523
## I added decompiled NjRat 0.7D Green Edition source code, but u need to fix it manually, because I'm stupid and I don't know Visual Basic

[NjRat](https://en.wikipedia.org/wiki/NjRAT) is a remote access tool ([RAT](https://en.wikipedia.org/wiki/Remote_desktop_software#RAT)) or trojan which allows the holder of the program to control the end-user's computer.
# Educational Purposes Only
Please do not use the program maliciously. This program is intended to be used for educational purposes only. Njrat is only used to demonstrate what type of information attackers can grab from a user's computer. This is a project was created to make it easier for malware analysts or ordinary users to understand how credential grabbing works and can be used for analysis, research, reverse engineering, or review. This software's intended purpose is NOT to be used maliciously, or on any system that you do not have own or have explicit permission to operate and use this program on. By using this software, you automatically agree to the above.
## Features
- Managers File: Seeing this, MAKE, upload, download, delete ON pc etc. Victims
- Open the file:
Through Links
Through Disk
Script: VBS, html, bat, txt etc.
- Desktop Control
- Control Camera / cam
- Control can cmd to review DDoS bot
- The process manager / task manager
- Keylogger: Seeing Anything That goal has typed on pc
- Create message: to chat Jump WITH Victims
- Check Password: Seeing ALL That Saved passwords in the browser application
- Server:
Update: Update through Link, Update through Disk
Restart
Remove Server
Resolve Network
Change the name in
Remove
## Video Showcase
[![Showcase](https://user-images.githubusercontent.com/65458800/140706416-62569215-beb1-4cb3-9821-102d1d22d4e3.png)](https://youtu.be/RjW717Ycyu0)
## Screenshots
![release](https://user-images.githubusercontent.com/65458800/115034575-574f4400-9ed4-11eb-9eed-f337fe50595f.png)
